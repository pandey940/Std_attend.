package com.example.punitpandey.studentattendance;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button b1=(Button) findViewById(R.id.Login);
        assert b1 !=null;
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText user = (EditText) findViewById(R.id.user_editText);
                EditText pass = (EditText) findViewById(R.id.pass_editText);
                ImageView resim = (ImageView) findViewById(R.id.imageView);

                if (pass == null || user == null || pass.getText().toString().isEmpty() || user.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter Username And Password", Toast.LENGTH_SHORT).show();
                } else if (!user.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "Please Enter Correct Password", Toast.LENGTH_SHORT).show();
                } else if (!pass.getText().toString().equals("1234")) {
                    Toast.makeText(getApplicationContext(), "Please Enter Correct Username", Toast.LENGTH_SHORT).show();
                } else {
                    assert resim != null;
                    resim.setImageResource(R.drawable.login);
                    Toast.makeText(getApplicationContext(), "Login Sucessfull", Toast.LENGTH_SHORT).show();

                    Intent i=new Intent(Login.this,Home.class);
                    startActivity(i);
                }
            }
        });


    }
}
