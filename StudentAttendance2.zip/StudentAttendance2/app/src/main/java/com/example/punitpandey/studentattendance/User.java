package com.example.punitpandey.studentattendance;

/**
 * Created by Punit Pandey on 26-Jan-18.
 */

public class User {
    private String name;
    private String sub;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public String getRoll() {
        return Roll;
    }

    public void setRoll(String roll) {
        Roll = roll;
    }

    private String Roll;
}
