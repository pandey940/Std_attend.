package com.example.punitpandey.studentattendance;

/**
 * Created by Punit Pandey on 26-Jan-18.
 */

public class Config_info {
    public static String uri="https://studentattendance-f0e65.firebaseio.com/";
}
