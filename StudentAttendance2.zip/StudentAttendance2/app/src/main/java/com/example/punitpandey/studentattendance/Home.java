package com.example.punitpandey.studentattendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

public class Home extends AppCompatActivity {

    Button btn_ok;
    EditText et_name, et_sub, et_Roll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        et_name = (EditText) findViewById(R.id.et_name);
        et_sub = (EditText) findViewById(R.id.et_sub);
        et_Roll = (EditText) findViewById(R.id.et_Roll);
        FirebaseApp.setAndroidContext(getApplicationContext());
    }

    public void click(View view)
    {
        String et1 = et_name.getText().toString();
        String et2 = et_Roll.getText().toString();
        String et3 = et_sub.getText().toString();

        if (et_name.equals("") | et_Roll.equals("") | et_sub.equals("")) {
            Toast.makeText(this, "please fill all the field", Toast.LENGTH_SHORT).show();
        } else {
            User user = new User();
            user.setName(et1);
            user.setRoll(et2);
            user.setSub(et3);

            FirebaseApp firebaseApp = new FirebaseApp(Config_info.uri);
            firebaseApp.child("person").setValue(user);

            Toast.makeText(this, "Data is Saved...", Toast.LENGTH_SHORT).show();
        }
    }
}


   /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
        }

        et_name = (EditText) findViewById(R.id.et_name);
        et_Roll = (EditText) findViewById(R.id.et_Roll);
        et_sub = (EditText) findViewById(R.id.et_sub);

        btn_ok = (Button) findViewById(R.id.btn_ok);

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = et_name.getText().toString();
                String Roll = et_Roll.getText().toString();
                String sub = et_sub.getText().toString();

                if (!name.equals("") && !Roll.equals("") && !sub.equals("")) {
                    saveTextAsFile(name, Roll, sub);
                }
            }
        });
    }

    private void saveTextAsFile(String name, String Roll, String sub) {
        String fileName = et_name + ".txt";

        //create file
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), fileName);

        //Write to file
        try {
            FileOutputStream fos  = new FileOutputStream(file);
            fos.write(Roll.getBytes());
            fos.close();
            Toast.makeText(this, "File Not Saved!", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "File Saved", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "File Error", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1000:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission not Granted", Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }
*/